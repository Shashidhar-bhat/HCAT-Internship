import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {
  contactForm!: FormGroup;
  successMessage = '';
  timerMessage = 'Please wait 5 seconds before submitting...';
  timerSeconds = 5;
  countdown: any;
  formVisible = true;
  darkMode = false;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.contactForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      message: ['', [Validators.required, Validators.minLength(5)]]
    });

    this.startTimer();
  }

  startTimer() {
    this.contactForm.disable();
    this.countdown = setInterval(() => {
      this.timerSeconds--;
      if (this.timerSeconds > 0) {
        this.timerMessage = `Please wait ${this.timerSeconds} seconds before submitting...`;
      } else {
        clearInterval(this.countdown);
        this.timerMessage = '';
        this.contactForm.enable();
      }
    }, 1000);
  }

  onSubmit() {
    if (this.contactForm.valid) {
      this.successMessage = "Thank you! Your message has been sent.";
      this.contactForm.reset();
      this.timerSeconds = 5;
      this.startTimer();
    } else {
      this.successMessage = '';
      this.contactForm.markAllAsTouched();
    }
  }

  toggleForm() {
    this.formVisible = !this.formVisible;
  }

  toggleDarkMode() {
    this.darkMode = !this.darkMode;
    document.body.classList.toggle('dark-mode', this.darkMode);
  }
}
