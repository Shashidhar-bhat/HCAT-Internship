import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  selectedArea: string = '';
  selectedService: string = '';

  areas: string[] = ['North Region', 'South Region', 'East Region', 'West Region'];
  services: string[] = ['General Checkup', 'Specialist Consultation', 'Home Care', 'Emergency Services'];

  onBookNow() {
    if (this.selectedArea && this.selectedService) {
      console.log(`Booking ${this.selectedService} in ${this.selectedArea}`);
      // Add your booking logic here
    } else {
      console.warn('Please select both area and service');
    }
  }
}
